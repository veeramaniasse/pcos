package com.example.pcos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class PatientLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.patient_login);
        Button button = findViewById(R.id.buttonLogin);
        button.setOnClickListener(view -> {
            // When button3 is clicked, start doctor_login activity
            Intent intent = new Intent(PatientLogin.this, EnterDetails.class);
            startActivity(intent);
        });

        TextView textView116 = findViewById(R.id.textView116);
        textView116.setOnClickListener(view -> {
            // When button3 is clicked, start doctor_login activity
            Intent intent = new Intent(PatientLogin.this, ForgotPassword.class);
            startActivity(intent);
        });

        };
    }