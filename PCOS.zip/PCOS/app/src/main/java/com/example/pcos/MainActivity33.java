package com.example.pcos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity33 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main33);
        Button button = findViewById(R.id.View2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity33.this, ExerciseList.class);
                startActivity(intent);
            }
        });
        Button View5 = findViewById(R.id.View5);
        View5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity33.this, ExerciseList.class);
                startActivity(intent);
            }
        });
        Button View4 = findViewById(R.id.View4);
        View4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity33.this, ExerciseList.class);
                startActivity(intent);
            }
        });
        Button View3 = findViewById(R.id.View3);
        View3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity33.this, ExerciseList.class);
                startActivity(intent);
            }
        });
        Button View6 = findViewById(R.id.View6);
        View6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity33.this, ExerciseList.class);
                startActivity(intent);
            }
        });
        Button button15 = findViewById(R.id.button15);
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity33.this, ExerciseList.class);
                startActivity(intent);
            }
        });
    }
}