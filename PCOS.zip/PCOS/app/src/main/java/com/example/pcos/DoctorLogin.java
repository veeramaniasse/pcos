package com.example.pcos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class DoctorLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.doctor_login);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(view -> {
            // When buttonLogin is clicked, start MainActivity20
            Intent intent = new Intent(DoctorLogin.this, DoctorHomepage.class);
            startActivity(intent);
        });

        TextView forgotPasswordText = findViewById(R.id.forgotPasswordText);
        forgotPasswordText.setOnClickListener(view -> {
            // When buttonLogin is clicked, start MainActivity20
            Intent intent = new Intent(DoctorLogin.this, ForgotPassword.class);
            startActivity(intent);
        });
    }
}
