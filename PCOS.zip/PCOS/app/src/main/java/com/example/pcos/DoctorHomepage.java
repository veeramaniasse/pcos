package com.example.pcos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class DoctorHomepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.doctor_homepage);


        Button button5 = findViewById(R.id.button5);
        button5.setOnClickListener(view -> {
            // When buttonLogin is clicked, start DoctorHomepage
            Intent intent = new Intent(DoctorHomepage.this, AddPatients.class);
            startActivity(intent);
        });

        Button button18 = findViewById(R.id.button18);
        button18.setOnClickListener(view -> {
            // When buttonLogin is clicked, start DoctorHomepage
            Intent intent = new Intent(DoctorHomepage.this, DoctorPatientView.class);
            startActivity(intent);
        });


        };
    }
