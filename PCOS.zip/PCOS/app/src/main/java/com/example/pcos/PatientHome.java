package com.example.pcos;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class PatientHome extends AppCompatActivity {

    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private ImageButton imageButton; // Change variable name to imageButton2

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patient_home);

        drawerLayout = findViewById(R.id.main);
        navigationView = findViewById(R.id.navigation_view);
        imageButton = findViewById(R.id.imageButton); // Change reference to imageButton2

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.edit_profile) {
                    startActivity(new Intent(PatientHome.this, PatientEditProfileActivity.class));
                } else if (id == R.id.about_pcos) {
                    startActivity(new Intent(PatientHome.this, MainActivity36.class));
                } else if (id == R.id.Reports) {
                    startActivity(new Intent(PatientHome.this, MedicalReports2.class));
                } else if (id == R.id.nav_logout) {
                    startActivity(new Intent(PatientHome.this, RollSelection.class));
                }

                // Close the navigation drawer
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        View button = findViewById(R.id.viewCenter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientHome.this, TrackView.class);
                startActivity(intent);
            }
        });

        ImageButton imageViewMiddle = findViewById(R.id.imageViewMiddle);
        imageViewMiddle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientHome.this, Calender.class);
                startActivity(intent);
            }
        });

        View view15 = findViewById(R.id.view15);
        view15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientHome.this, FoodMenu.class);
                startActivity(intent);
            }
        });

        View View6 = findViewById(R.id.View6);
        View6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientHome.this, MainActivity33.class);
                startActivity(intent);
            }
        });

        ImageButton imageButton2 = findViewById(R.id.imageButton2);
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientHome.this, PatientProfile.class);
                startActivity(intent);
            }
        });

        View secondView = findViewById(R.id.secondView);
        secondView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientHome.this, TodayProgressPatients.class);
                startActivity(intent);
            }
        });

        View thirdView = findViewById(R.id.thirdView);
        thirdView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientHome.this, MeditationHomeActivity.class);
                startActivity(intent);
            }
        });
    }
}
