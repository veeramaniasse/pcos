package com.example.pcos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DoctorPatientView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.doctor_patient_view);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        View View2 = findViewById(R.id.View2);
        View2.setOnClickListener(view -> {
            // When buttonLogin is clicked, start DoctorHomepage
            Intent intent = new Intent(DoctorPatientView.this, PatientEditProfile.class);
            startActivity(intent);
        });

        View View3 = findViewById(R.id.View3);
        View3.setOnClickListener(view -> {
            // When buttonLogin is clicked, start DoctorHomepage
            Intent intent = new Intent(DoctorPatientView.this, TrackShowActivity.class);
            startActivity(intent);
        });

        View View4 = findViewById(R.id.View4);
        View4.setOnClickListener(view -> {
            // When buttonLogin is clicked, start DoctorHomepage
            Intent intent = new Intent(DoctorPatientView.this, PatientMenstrualCalenderActivity.class);
            startActivity(intent);
        });

        View View5 = findViewById(R.id.View5);
        View5.setOnClickListener(view -> {
            // When buttonLogin is clicked, start DoctorHomepage
            Intent intent = new Intent(DoctorPatientView.this, TodayProgressDoctor.class);
            startActivity(intent);
        });

        View View1 = findViewById(R.id.View1);
        View1.setOnClickListener(view -> {
            // When buttonLogin is clicked, start DoctorHomepage
            Intent intent = new Intent(DoctorPatientView.this, MedicalReports.class);
            startActivity(intent);
        });


    }
}