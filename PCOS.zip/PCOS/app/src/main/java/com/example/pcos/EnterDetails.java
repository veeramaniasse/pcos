package com.example.pcos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class EnterDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.enter_details);

        // Spinner setup
        Spinner spinner = findViewById(R.id.editTextText12);
        String[] items = {"No Child","Single Child", "Two Child", "More than 2 Child","Unmarried"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        Button button11 = findViewById(R.id.button11);
        button11.setOnClickListener(view -> {
            // When button11 is clicked, start Welcome activity
            Intent intent = new Intent(EnterDetails.this, Welcome.class);
            startActivity(intent);
        });
    }
}
