package com.example.pcos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Welcome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.welcome);

        ImageView imageView = findViewById(R.id.imageView3); // Replace imageView with your actual ImageView ID
        imageView.setOnClickListener(view -> {
            // Start the quesandanans activity
            Intent intent = new Intent(Welcome.this, QuestionAndAnswers1.class);
            startActivity(intent);
        });
    }
}
